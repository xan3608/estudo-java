public class TestaPontoFlutuante{

    public static void main(String[] args){

        double salario = 1250.70;

        System.out.println("meu salario é " + salario);
        
        double divisao = 5.0 / 2;
        System.out.println("divisao: " + divisao);

    }
}